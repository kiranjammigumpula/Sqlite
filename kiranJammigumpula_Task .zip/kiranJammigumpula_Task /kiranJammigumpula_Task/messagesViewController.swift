//
//  messagesViewController.swift
//  kiranJammigumpula_Task
//
//  Created by IBLE-MACAIR on 09/07/20.
//  Copyright © 2020 IBLE-MACAIR. All rights reserved.
//

import UIKit
import SQLite3
class messagesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    let navBarButton =  UIButton(type: .custom)
    let btn1 = UIButton(type: .custom)
    let btn2 = UIButton(type: .custom)
    let btn3 = UIButton(type: .custom)
    let btn4 = UIButton(type: .custom)
    let btn5 = UIButton(type: .custom)
    
    var db: OpaquePointer?
    var messagesList = [Messages]()
    
    @IBOutlet weak var submitTxtBtn: UIButton!
    @IBOutlet weak var messagesTblView: UITableView!
    @IBOutlet weak var messageTxtView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
      setnavigation()
    self.navigationController?.navigationBar.isHidden = false
    self.navigationController?.navigationBar.barTintColor = UIColor.green
    messagesTblView.register(UINib(nibName: "presonalMSgTableViewCell", bundle: nil),forCellReuseIdentifier: "presonalMSgTableViewCell")
    self.messagesTblView.dataSource = self
    self.messagesTblView.delegate = self
    self.messagesTblView.reloadData()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
   view.addGestureRecognizer(tap)
        self.messageTxtView.layer.cornerRadius = 6.0
        self.messageTxtView.layer.borderWidth = 1.0
        self.submitTxtBtn.layer.borderWidth = 1.0
        self.submitTxtBtn.layer.cornerRadius = 6.0
        
  let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("messagesDatabase.sqlite")
        
        
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("error opening database")
        }
        
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Heroes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, powerrank INTEGER)", nil, nil, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        }
        
        readValues()
    }
     //MARK: - navigation methods
    func setnavigation() {
        btn1.setImage(UIImage(named:"backBtn"), for: .normal)
        btn1.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        let item1 = UIBarButtonItem(customView: btn1)
        btn2.setTitle("Kiran jammigumpula", for: .normal)
        btn2.frame = CGRect(x: 0, y: 10, width: 20, height: 20)
        let item2 = UIBarButtonItem(customView: btn2)
        self.navigationItem.setLeftBarButtonItems([item1,item2], animated: true)
        btn3.setImage(UIImage(named:"menuIcon"), for: .normal)
        btn3.frame = CGRect(x: 0,y:10, width:20,height: 20)
        
        let item3 = UIBarButtonItem(customView:btn3)
        btn4.setImage(UIImage(named:"callIcon2"), for: .normal)
        btn4.frame = CGRect(x: 0,y:10, width:20,height: 20)
        
        let item4 = UIBarButtonItem(customView:btn4)
        btn5.setImage(UIImage(named:"callIcon"), for: .normal)
        btn5.frame = CGRect(x:0,y:10, width:30,height: 30)
        
        let item5 = UIBarButtonItem(customView:btn5)
        self.navigationItem.setRightBarButtonItems([item3,item4,item5], animated: true)
        }
    //MARK: - Keyboard hide methods
    @objc func dismissKeyboard() {
    view.endEditing(true)
    }
//MARK: - Tableview delegate methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messagesList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell( withIdentifier: "presonalMSgTableViewCell",for: indexPath)as! presonalMSgTableViewCell
        cell.backgroundColor = UIColor.white
        let message: Messages
        message = messagesList[indexPath.row]
        cell.textLabel?.text = message.entertedMessage
        return cell
    }
    //MARK: - UiButton actions
    
    @IBAction func submitBtnAct(_ sender: Any) {
        let name = messageTxtView.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        if(name?.isEmpty)!{
            messageTxtView.layer.borderColor = UIColor.red.cgColor
            return
        }
        
        var stmt: OpaquePointer?
        
        let queryString = "INSERT INTO Heroes (name, powerrank) VALUES (?,?)"
        
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return
        }
        
        if sqlite3_bind_text(stmt, 1, name, -1, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure binding name: \(errmsg)")
            return
        }
        if sqlite3_step(stmt) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure inserting hero: \(errmsg)")
            return
        }
        messageTxtView.text=""
        readValues()
        print("message saved successfully")
    }
    
    //MARK: - Get messages method
    func readValues(){
        messagesList.removeAll()

        let queryString = "SELECT * FROM Heroes"
        
        var stmt:OpaquePointer?
        
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return
        }
        
        while(sqlite3_step(stmt) == SQLITE_ROW){
        let msg = String(cString: sqlite3_column_text(stmt, 1))
        messagesList.append(Messages(textMessage: String(describing: msg)))
        }
        
        self.messagesTblView.reloadData()
    }
}
