//
//  ViewController.swift
//  kiranJammigumpula_Task
//
//  Created by IBLE-MACAIR on 09/07/20.
//  Copyright © 2020 IBLE-MACAIR. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
@IBOutlet weak var headerBgView: UIView!
@IBOutlet weak var dotsMenuIconBtn: UIButton!
@IBOutlet weak var searchIconBtn: UIButton!
@IBOutlet weak var whatsAppTxtLbl: UILabel!
@IBOutlet weak var segmentView: UISegmentedControl!
@IBOutlet weak var footerBgView: UIView!
@IBOutlet weak var chatsTblView: UITableView!
@IBOutlet weak var newChatBtn: UIButton!
    let cellReuseIdentifier = "ChatsTableViewCell"
    var contactsArray = ["Kiran Jammigumpula","Ashok","Venkat Anish","Raviteja","Krishna teja","Abhijitj","RajaShekarReddy","Manish","Suresh","Jagadeesh"]
    var messagesArray = ["Hi How are you","Hello How are you","What are doing Anish","Hows your work going on"," Are you there","please call me","Be on time","Call me once","Please be on time","Make it fast"]
//    var profilePicsArray = ["Image","Image-1","Image-2","Image-3","Image-4","Image-5","Image-6","Image-7","Image-8","Image-9"]
    var msgTimeArray = ["06:00 Am","07:00 Am","08:00 Am","09:00 Am","10:00 Am","07:00 pm","08:00 Pm","Yesterday","8/7/2020","6/7/2020"]
    var profilePicsArray = [#imageLiteral(resourceName: "Image-7"),#imageLiteral(resourceName: "Image-6"),#imageLiteral(resourceName: "Image-8"),#imageLiteral(resourceName: "Image-9"),#imageLiteral(resourceName: "Image-1"),#imageLiteral(resourceName: "Image-4"),#imageLiteral(resourceName: "Image-2"),#imageLiteral(resourceName: "Image-5"),#imageLiteral(resourceName: "Image-3"),#imageLiteral(resourceName: "Image-6")]
    var chartsDict: Dictionary<String, [Any]> = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        newChatBtn.layer.borderWidth = 1.0
        newChatBtn.layer.masksToBounds = false
        newChatBtn.layer.borderColor = UIColor.white.cgColor
        newChatBtn.clipsToBounds = true
        newChatBtn.layer.cornerRadius = 0.5*newChatBtn.frame.width
//        chartsDict.setValue(profilePicsArray, forKey: "profilePics")
//        chartsDict.setValue(messagesArray, forKey: "messages")
//        chartsDict.setValue(contactsArray, forKey: "contacts")
//        chartsDict.setValue(msgTimeArray, forKey: "msgTimes")
        chartsDict["profilePics"] = self.profilePicsArray
        chartsDict["messagesArray"] = self.messagesArray
        chartsDict["contactsArray"] = self.contactsArray
        chartsDict["msgTimeArray"] = self.msgTimeArray
        chatsTblView.register(UINib(nibName: "ChatsTableViewCell", bundle: nil),
        forCellReuseIdentifier: cellReuseIdentifier)
        self.chatsTblView.dataSource = self
        self.chatsTblView.delegate = self
        self.chatsTblView.reloadData()
    }
//MARK: - Tableview delegate methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell( withIdentifier: "ChatsTableViewCell",for: indexPath)as! ChatsTableViewCell
           cell.backgroundColor = UIColor.white
        var picArray:NSArray!
        var conatcstArray:NSArray!
        var messagesArray:NSArray!
        var timeArray:NSArray!
        if segmentView.selectedSegmentIndex == 0{
        cell.callImgView.isHidden = true
        cell.timeTxtLbl.isHidden = false
            
            print("chartsDict Array\(chartsDict)")
            picArray = chartsDict["profilePics"] as NSArray?
            conatcstArray = chartsDict["contactsArray"] as NSArray?
            messagesArray = chartsDict["messagesArray"] as NSArray?
            timeArray = chartsDict["msgTimeArray"] as NSArray?
            print("profile Array\(picArray!)")
            print("conatcstArray Array\(conatcstArray!)")
            print("messagesArray Array\(messagesArray!)")
            print("timeArray Array\(timeArray!)")
            cell.profilePicImgView.image = profilePicsArray[indexPath.row]
            cell.contactsTxtLbl.text = conatcstArray[indexPath.row] as? String
            cell.messageTxtLbl.text = messagesArray[indexPath.row] as? String
            cell.timeTxtLbl.text = timeArray[indexPath.row] as? String
        }
        else if segmentView.selectedSegmentIndex == 1{
        cell.callImgView.isHidden = true
        cell.timeTxtLbl.isHidden = true
        }
        else{
        cell.callImgView.isHidden = false
        cell.timeTxtLbl.isHidden = true
        cell.messageTxtLbl.text = "9/8/2020"
        }
        cell.profilePicImgView.layer.borderWidth = 1.0
        cell.profilePicImgView.layer.masksToBounds = false
        cell.profilePicImgView.layer.borderColor = UIColor.white.cgColor
        cell.profilePicImgView.layer.cornerRadius = cell.profilePicImgView.frame.size.width/2
        cell.profilePicImgView.clipsToBounds = true
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 72
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//   let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
    let nextViewController = storyboard?.instantiateViewController(withIdentifier: "messagesViewController") as! messagesViewController
   self.navigationController?.pushViewController(nextViewController, animated: true)
    tableView.deselectRow(at: indexPath, animated: true)
    }
    //MARK: - Button action methods
@IBAction func segmentAct(_ sender: Any) {
    self.chatsTblView.delegate = self
    self.chatsTblView.dataSource = self
    self.chatsTblView.reloadData()
    }
    //MARK: - cell action method
    func cellaction()  {
      let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "messagesViewController") as! messagesViewController
       self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}

