//
//  StatusTableViewCell.swift
//  kiranJammigumpula_Task
//
//  Created by IBLE-MACAIR on 09/07/20.
//  Copyright © 2020 IBLE-MACAIR. All rights reserved.
//

import UIKit

class StatusTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
