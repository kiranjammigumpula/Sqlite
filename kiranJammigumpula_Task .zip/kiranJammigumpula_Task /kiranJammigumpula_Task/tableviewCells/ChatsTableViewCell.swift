//
//  ChatsTableViewCell.swift
//  kiranJammigumpula_Task
//
//  Created by IBLE-MACAIR on 09/07/20.
//  Copyright © 2020 IBLE-MACAIR. All rights reserved.
//

import UIKit

class ChatsTableViewCell: UITableViewCell {

    @IBOutlet weak var profilePicImgView: UIImageView!
    @IBOutlet weak var timeTxtLbl: UILabel!
@IBOutlet weak var messageTxtLbl: UILabel!
    @IBOutlet weak var callImgView: UIImageView!
    @IBOutlet weak var contactsTxtLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
 
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
