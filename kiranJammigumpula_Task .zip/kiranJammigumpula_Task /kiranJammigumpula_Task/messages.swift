//
//  messages.swift
//  kiranJammigumpula_Task
//
//  Created by IBLE-MACAIR on 10/07/20.
//  Copyright © 2020 IBLE-MACAIR. All rights reserved.
//
class Messages {
var entertedMessage: String?
init( textMessage: String?){
self.entertedMessage = textMessage
    }
}

